# Créa3 et Fuji Tomy — Propositions de refonte

Deux sites statiques indépendants, HTML/CSS/JavaScript sans dépendance. Propositions de refonte, sans remplacement des sites officiels. Photographies et informations issues des sites clients, vérifiées le 7 octobre 2026. Les prix et horaires doivent être validés par le restaurant avant mise en production. Présentation à réaliser sur des liens Render.

## Publication Render

Les fichiers sont regroupés à la racine pour permettre leur import via GitHub. Chaque site conserve ses propres fichiers préfixés. La construction copie uniquement les fichiers du client concerné dans un dossier public, avec sa page d'accueil renommée index.html.

Créa3 : commande `mkdir -p public && cp crea3-index.html public/index.html && cp crea3-* public/`, dossier publié `public`.
Fuji Tomy : commande `mkdir -p public && cp fujitomy-index.html public/index.html && cp fujitomy-* public/`, dossier publié `public`.

Aucune dépendance, aucun service payant requis. Les URL finales sont celles attribuées par Render.

## Fonctionnalités et limites

Créa3 : galerie avec quatre projets documentés, détails en fenêtre modale et seconde vue, filtres, comparaison avant/après, contact préparant un email dans la messagerie de l'utilisateur. Aucun formulaire n'envoie silencieusement de données.

Fuji Tomy : dix menus tirés de la carte, recherche et filtres, liens officiels Tablemi et Uber Eats, téléphone et itinéraire. L'état d'ouverture suit les horaires publiés, en heure de Paris, sans prise en compte des fermetures exceptionnelles. La réservation passe par téléphone.

Démonstrations exclues de l'indexation. Aucun faux avis, aucune réservation fictive, aucun outil de suivi. Validation sur 360, 390 et 1440 pixels : aucun débordement horizontal, images présentes, aucune erreur JavaScript. Navigation mobile, clavier Escape, fenêtres de détail, galerie, filtres et recherche testés.

## Sources

- https://www.crea3.fr/
- https://www.crea3.fr/realisations/asnieres-b
- https://www.crea3.fr/realisations/paris-75007-d
- https://www.crea3.fr/realisations/saint-ouen
- https://www.crea3.fr/realisations/paris-75007-c
- https://www.fujitomy.com/fr/

Les textes de présentation sont adaptés à la proposition. Les projets et les plats sont ceux des clients. Ne pas réutiliser les photographies ou marques pour d'autres entreprises.
