# Deux propositions de refonte — version 4

Créa3 : portfolio avec galeries, filtres, avant/après et contact email.
Fuji Tomy : carte filtrable, recherche et liens officiels de commande.

Photographies et informations issues des sites clients. Démonstrations indépendantes.
Vérifications : 1440, 390 et 360 px, images, débordement, galeries, filtres, recherche, clavier et menus mobiles.
