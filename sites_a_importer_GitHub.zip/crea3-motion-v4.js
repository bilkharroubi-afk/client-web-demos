
(()=>{
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
const saveData=navigator.connection?.saveData;
const scene=document.querySelector('.depth-scene');
const video=document.querySelector('.cinema-video');
const motion=document.querySelector('.motion-toggle');
const film=document.querySelector('.cinema-dialog');
const filmVideo=film.querySelector('video');
const setMotion=()=>{motion.textContent=video.paused?'Animer la vue':'Mettre en pause';motion.setAttribute('aria-pressed',String(!video.paused))};
video.addEventListener('playing',()=>{video.classList.add('is-playing');setMotion()});
video.addEventListener('pause',setMotion);
video.addEventListener('error',()=>{video.classList.remove('is-playing');motion.hidden=true});
motion.onclick=()=>{if(video.paused){video.src ||=video.dataset.src;video.play().catch(()=>setMotion())}else video.pause()};
if(!reduce.matches&&!saveData&&matchMedia('(min-width:761px)').matches){video.src=video.dataset.src;video.play().catch(()=>setMotion())}
document.querySelector('.film-button').onclick=()=>{film.showModal();filmVideo.src ||=filmVideo.dataset.src;filmVideo.play().catch(()=>{})};
film.querySelector('.dialog-close').onclick=()=>film.close();
film.addEventListener('close',()=>filmVideo.pause());
film.addEventListener('click',e=>{if(e.target===film){const r=film.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)film.close()}});
if(!reduce.matches&&matchMedia('(hover:hover) and (pointer:fine)').matches){
let frame;scene.addEventListener('pointermove',e=>{if(frame)cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const r=scene.getBoundingClientRect();scene.style.setProperty('--rx',((.5-(e.clientY-r.top)/r.height)*6)+'deg');scene.style.setProperty('--ry',(((e.clientX-r.left)/r.width-.5)*7)+'deg')})});
scene.addEventListener('pointerleave',()=>{scene.style.setProperty('--rx','0deg');scene.style.setProperty('--ry','0deg')});
}
document.querySelectorAll('.hero-controls button').forEach(b=>b.addEventListener('click',()=>{video.pause();video.classList.remove('is-playing')}));
const progress=document.querySelector('.scroll-progress');let scrollFrame;
addEventListener('scroll',()=>{if(scrollFrame)return;scrollFrame=requestAnimationFrame(()=>{const d=document.documentElement;progress.style.transform='scaleX('+Math.max(0,Math.min(1,scrollY/(d.scrollHeight-innerHeight||1)))+')';scrollFrame=0})},{passive:true});
if(!reduce.matches&&'IntersectionObserver' in window){const obs=new IntersectionObserver(items=>items.forEach(x=>{if(x.isIntersecting){x.target.classList.add('is-visible');obs.unobserve(x.target)}}),{threshold:.08});document.querySelectorAll('.section .heading,.section-heading,.steps article,.statement>p,.agency-text').forEach(el=>{el.classList.add('reveal-ready');obs.observe(el)})}
document.addEventListener('visibilitychange',()=>{if(document.hidden){video.pause();filmVideo.pause()}});
reduce.addEventListener('change',()=>{if(reduce.matches){video.pause();video.classList.remove('is-playing')}});
setMotion();
})();
